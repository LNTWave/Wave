﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VMSWeb.Models;

namespace VMCWeb.ViewModel
{
    public class VisitorViewModel
    {
        public List<VisitorModel> visitorList { get; set; }
        public string strInvite { get; set; }
        

    }



}