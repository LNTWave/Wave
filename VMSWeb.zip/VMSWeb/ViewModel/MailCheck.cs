﻿using AE.Net.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using VMS;

namespace VMCWeb.ViewModel
{
    public class MailCheck
    {
        private String subject, sendEmailTo, Body, FromAddress = "";
        private String hostCompanyName, Location, StartDate, StartTime, EndDate, EndTime;
        private Thread sendEMailThread = null;
        private ImapClient ic;
        private Host newHost;
        private Meeting newMeeting;
        private Visitor newVisitor;
        private List<string> ValidHostEmailIDS;
        private string hostid;


        public void sendEmail()
        {
            SmtpClient client = new SmtpClient();
            client.Port = 587;
            client.Host = "smtp-mail.outlook.com";
            client.EnableSsl = true;
            client.Timeout = 90000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("visitormanagementapp@outlook.com", "VisitorManagement");

            string inviteeCode = GenerateInvitationCode("Honeywell212");

            try
            {
                string[] arr = Body.Split('=');
                Body = arr[0];
            }
            catch
            {
            }
            try
            {
                using (StringReader sr = new StringReader(Body))
                {
                    string line;
                    String[] token;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains("Location"))
                        {
                            token = line.Split(new[] { "Location:" }, StringSplitOptions.None);
                            Location = token[1];
                        }
                        else if (line.Contains("Start Date"))
                        {
                            token = line.Split(new[] { "Start Date:" }, StringSplitOptions.None);
                            StartDate = token[1];
                        }
                        else if (line.Contains("Start Time"))
                        {
                            token = line.Split(new[] { "Start Time:" }, StringSplitOptions.None);
                            StartTime = token[1];
                        }
                        else if (line.Contains("End Date"))
                        {
                            token = line.Split(new[] { "End Date:" }, StringSplitOptions.None);
                            EndDate = token[1];
                        }
                        else if (line.Contains("End Time"))
                        {
                            token = line.Split(new[] { "End Time:" }, StringSplitOptions.None);
                            EndTime = token[1];
                        }
                    }
                }
            }
            catch
            {
            }

            String finalMessage = "Hi Visitor," + " \nBelow are your meeting details : \n" + Body + "\n" +
                 "\n Invitee code : "
                      + inviteeCode + "\n\n\n" +
              "Download the App from here: http://www.google.com" +
                      "\n\nThis is a system generated mail. Please do not reply.";

            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage("visitormanagementapp@outlook.com", sendEmailTo, subject, finalMessage);
            mail.BodyEncoding = UTF8Encoding.UTF8;
            mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

            client.Send(mail);
            UpdateMeetingAndVisitorInfo(subject, sendEmailTo, Body, inviteeCode);

        }

        public void UpdateMeetingAndVisitorInfo(string subject, string sendEmailTo, string Body, string inviteeCode)
        {
            newHost.HostID = hostid;
            newHost.HostName = FromAddress.Split('@')[0];
            newHost.EmailId = FromAddress;
            newHost.CompanyID = "LT";
            newHost.Department = "SW";
            newHost.StatusID = 1;
            newHost.Designation = "Project Manager";
            newHost.PhoneNo = "1234567890";

            newMeeting.MeetingID = newMeeting.HostID = hostid;
            newMeeting.MeetingName = subject;
            newMeeting.MeetingDate = Convert.ToDateTime(StartDate);
            newMeeting.Location = "Bangalore";

            newVisitor.VisitorID = newVisitor.VisitorMailID = sendEmailTo;
            newVisitor.Name = sendEmailTo;
            newVisitor.MeetingID = newMeeting.MeetingID;
            newVisitor.InvitationCode = inviteeCode;

            VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
            dal.AddHostMeetingVisitorDetails(newHost, newMeeting, newVisitor);
        }

        public string GenerateInvitationCode(string companyCode)
        {
            string strInviteCode = string.Empty;
            strInviteCode = companyCode.Substring(0, 4).ToUpper() + "-" + GetUniqueKey(12);
            return strInviteCode;
        }

        public string GetUniqueKey(int maxSize)
        {
            char[] chars = new char[62];
            chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
            byte[] data = new byte[1];
            using (RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider())
            {
                crypto.GetNonZeroBytes(data);
                data = new byte[maxSize];
                crypto.GetNonZeroBytes(data);
            }
            StringBuilder result = new StringBuilder(maxSize);
            foreach (byte b in data)
            {
                result.Append(chars[b % (chars.Length)]);
            }
            string strResult = Regex.Replace(result.ToString(), @"(.{4})", "$1-");

            //for (int i = 4; i < strResult.Length; i += 4)
            //{
            //    strResult = strResult.Insert(i, "-");
            //    i++;
            //}
            return strResult.TrimEnd('-');
        }

        public void scan_email()
        {
            try
            {
                ic = new ImapClient("imap-mail.outlook.com", "visitormanagementapp@outlook.com", "VisitorManagement", AuthMethods.Login, 993, true);
                // Select a mailbox. Case-insensitive imap-mail.outlook.com
                var inbox = ic.SelectMailbox("INBOX");

                //Console.WriteLine(ic.GetMessageCount());
                if (ic.GetMessageCount() > 0)
                {
                    AE.Net.Mail.MailMessage[] mm = ic.GetMessages(0, ic.GetMessageCount() - 1, false);

                    foreach (AE.Net.Mail.MailMessage m in mm)
                    {
                        //Location: Orchid meeting room
                        //Start Time: Thu 25-Aug-16 4:00 PM
                        //End Time: Thu 25-Aug-16 4:30 PM
                        //if (m.Flags != Flags.Seen)
                        {
                            hostCompanyName = m.From.Host;
                            hostCompanyName = hostCompanyName.Split('.')[0];
                            Body = m.Body;
                            FromAddress = m.From.ToString();
                            subject = m.Subject;

                            hostid = FromAddress + Convert.ToString(DateTime.Now);

                            foreach (System.Net.Mail.MailAddress k in m.To)
                            {
                                String toAddress = k.Address;
                                if (!toAddress.Equals("visitormanagementapp@outlook.com"))
                                {
                                    sendEmailTo = k.Address;
                                }
                                sendEMailThread = new Thread(new ThreadStart(sendEmail));
                            }
                            sendEMailThread.Start();
                            ic.DeleteMessage(m);
                        }
                    }
                }
                ic.Expunge();
                ic.Dispose();

            }
            catch (Exception ex)
            {
                // Console.WriteLine(ex.Message);
            }
        }

        public void Main()
        {
            try
            {
                ValidHostEmailIDS = new List<string>();

                newHost = new Host();
                newMeeting = new Meeting();
                newVisitor = new Visitor();
                //scan_email(null, null);
                //System.Timers.Timer checkMailTimer = new System.Timers.Timer();
                //checkMailTimer.Interval = 300000;
                //checkMailTimer.Elapsed += scan_email;
                //checkMailTimer.Start();
                ////System.Threading.Timer t = new System.Threading.Timer(scan_email, null, 0, 300000);
                sendEmail();
                //var autoEvent = new AutoResetEvent(false);
                //var stateTimer = new System.Threading.Timer(scan_email,
                //autoEvent, 0, 30000);
                //autoEvent.WaitOne();
                //stateTimer.Dispose();
                //Console.WriteLine("\nDestroying timer.");

            }
            catch (Exception ex)
            {
                // Console.WriteLine(ex.Message);
            }
        }
    }
}