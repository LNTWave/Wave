﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VMSWeb.Models
{
    public class InviteCodeModel
    {
        private bool _success;
        private string _message;
        private string _token;
        private string _meetingDate;
        private string _meetingTime;
        private string _hostName;
        private string _hostEmailID;
        private string _location;
        private string _qrCode;
        private string _meetingID;
        private bool _isUserRegistered;
        private string _designation;
        private string _phone;

        private string _InviteeCode;
        private string _HostLocation;
        private string _HostCompanyName;
        private string _VisitorEmailID;
        private string _VisitorName;
        private string _CheckedInStatus;
        private string _TimeIn;
        private string _TimeOut;

        /// <summary>
        /// Property Success or Not
        /// </summary>
        public bool Success
        {
            get { return _success; }
            set { _success = value; }
        }

        /// <summary>
        /// Property Message for success or failure
        /// </summary>
        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }

        /// <summary>
        /// Property Token
        /// </summary>
        public string Token
        {
            get { return _token; }
            set { _token = value; }
        }

        /// <summary>
        /// Property Meeting Date
        /// </summary>
        public string MeetingDate
        {
            get { return _meetingDate; }
            set { _meetingDate = value; }
        }

        /// <summary>
        /// Property Meeting Time
        /// </summary>
        public string MeetingTime
        {
            get { return _meetingTime; }
            set { _meetingTime = value; }
        }

        /// <summary>
        /// Property HostName
        /// </summary>
        public string HostName
        {
            get { return _hostName; }
            set { _hostName = value; }
        }

        /// <summary>
        /// Property Host Email ID
        /// </summary>
        public string HostEmailID
        {
            get { return _hostEmailID; }
            set { _hostEmailID = value; }
        }

        /// <summary>
        /// Property Location
        /// </summary>
        public string Location
        {
            get { return _location; }
            set { _location = value; }
        }

        /// <summary>
        /// Property QRCode
        /// </summary>
        public string QRCode
        {
            get { return _qrCode; }
            set { _qrCode = value; }
        }

        /// <summary>
        /// Property MeetingID
        /// </summary>
        public string MeetingID
        {
            get { return _meetingID; }
            set { _meetingID = value; }
        }

        /// <summary>
        /// Property User Registration
        /// </summary>
        public bool ISUserRegistered
        {
            get { return _isUserRegistered; }
            set { _isUserRegistered = value; }
        }

        /// <summary>
        /// Property Designation
        /// </summary>
        public string Designation
        {
            get { return _designation; }
            set { _designation = value; }
        }

        /// <summary>
        /// Property Phone
        /// </summary>
        public string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }

        public string InviteeCode
        {
            get { return _InviteeCode; }
            set { _InviteeCode = value; }
        }

        public string HostLocation
        {
            get { return _HostLocation; }
            set { _HostLocation = value; }
        }

        public string HostCompanyName
        {
            get { return _HostCompanyName; }
            set { _HostCompanyName = value; }
        }

        public string VisitorEmailID
        {
            get { return _VisitorEmailID; }
            set { _VisitorEmailID = value; }
        }

        public string VisitorName
        {
            get { return _VisitorName; }
            set { _VisitorName = value; }
        }

        public string CheckedInStatus
        {
            get { return _CheckedInStatus; }
            set { _CheckedInStatus = value; }
        }

        public string TimeIn
        {
            get { return _TimeIn; }
            set { _TimeIn = value; }
        }

        public string TimeOut
        {
            get { return _TimeOut; }
            set { _TimeOut = value; }
        }
    }
}
