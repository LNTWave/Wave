﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VMSWeb.Models
{
    public class VisitorModel
    {
        private string _VisitorID;
        private string _Name;
        private string _Company;
        private string _Designation;
        private byte[] _ScanPhoto;
        private string _MeetingID;
        private string _InvitationCode;
        private DateTime  _TimeIN;
        private DateTime _TimeOUT;
        //private string _QRCodeID;
        private string _Comments;
        private int _BadgeNo;
        private string _VisitorMailID;
        private int _StatusID;
        private string _Nationality;
        private string _Address;
        private string _Token;
        private byte[] _ScanDocument;
        private string _PhoneNo;
        private string _DeviceID;
        private string _HostName;
        private string _CDesignation;
        private string _HPhoneNo;
        private string _HostID;
        /// <summary>
        /// Property for Comments
        /// </summary>
        public string Comments
        {
            get { return _Comments; }
            set { _Comments = value; }
        }

        /// <summary>
        /// Property for VisitorID
        /// </summary>
        public string VisitorID
        {
            get { return _VisitorID; }
            set { _VisitorID = value; }
        }

        
        /// <summary>
        /// Property for Name
        /// </summary>
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        
        /// <summary>
        /// Property for Company
        /// </summary>
        public string Company
        {
            get { return _Company; }
            set { _Company = value; }
        }

        /// <summary>
        /// Property for Designation
        /// </summary>
        public string Designation
        {
            get { return _Designation; }
            set { _Designation = value; }
        }

        
        /// <summary>
        /// Property for ScanPhoto
        /// </summary>
        public byte[] ScanPhoto
        {
            get { return _ScanPhoto; }
            set { _ScanPhoto = value; }
        }

        
         /// <summary>
        /// Property for MeetingID
        /// </summary>
        public string MeetingID
        {
            get { return _MeetingID; }
            set { _MeetingID = value; }
        }

        /// <summary>
        /// Property for InvitationCode
        /// </summary>
        public string InvitationCode
        {
            get { return _InvitationCode; }
            set { _InvitationCode = value; }
        }

        /// <summary>
        /// Property for TimeIN
        /// </summary>
        public DateTime TimeIN
        {
            get { return _TimeIN; }
            set { _TimeIN = value; }
        }

        /// <summary>
        /// Property for TimeIN
        /// </summary>
        public DateTime TimeOUT
        {
            get { return _TimeOUT; }
            set { _TimeOUT = value; }
        }

        /// <summary>
        /// Property for QRCodeID
        /// </summary>
        //public string QRCodeID
        //{
        //    get { return _QRCodeID; }
        //    set { _QRCodeID = value; }
        //}

        
        /// <summary>
        /// Property for BadgeNo
        /// </summary>
        public int BadgeNo
        {
            get { return _BadgeNo; }
            set { _BadgeNo = value; }
        }

        /// <summary>
        /// Property for VisitorMailID
        /// </summary>
        public string VisitorMailID
        {
            get { return _VisitorMailID; }
            set { _VisitorMailID = value; }
        } 

        /// <summary>
        /// Property for StatusID
        /// </summary>
        public int StatusID
        {
            get { return _StatusID; }
            set { _StatusID = value; }
        }
        
        /// <summary>
        /// Property for Nationality
        /// </summary>
        public string Nationality
        {
            get { return _Nationality; }
            set { _Nationality = value; }
        } 

        /// <summary>
        /// Property for Address
        /// </summary>
        public string Address
        {
            get { return _Address; }
            set { _Address = value; }
        } 

        /// <summary>
        /// Property for Token
        /// </summary>
        public string Token
        {
            get { return _Token; }
            set { _Token = value; }
        } 
         
        /// <summary>
        /// Property for ScanDocument
        /// </summary>
        public byte[] ScanDocument
        {
            get { return _ScanDocument; }
            set { _ScanDocument = value; }
        }
        
        /// <summary>
        /// Property for PhoneNo
        /// </summary>
        public string PhoneNo
        {
            get { return _PhoneNo; }
            set { _PhoneNo = value; }
        }

        /// <summary>
        /// Property for DeviceID
        /// </summary>
        public string DeviceID
        {
            get { return _DeviceID; }
            set { _DeviceID = value; }
        }

        public string HostName
        {
            get { return _HostName; }
            set { _HostName = value; }
        }

        public string CDesignation
        {
            get { return _CDesignation; }
            set { _CDesignation = value; }
        }

        public string HPhoneNo
        {
            get { return _HPhoneNo; }
            set { _HPhoneNo = value; }
        }

        public string HostID
        {
            get { return _HostID; }
            set { _HostID = value; }
        }

    }

}
