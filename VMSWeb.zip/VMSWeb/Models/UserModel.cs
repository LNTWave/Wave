﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VMSWeb.Models
{
    public class UserModel
    {
        public UserModel()
        {
        }

        private string _empid;
        private string _empName;
        private string _company;
        private string _department;
        private string _empType;

        /// <summary>
        /// Property EmpId
        /// </summary>
        public string EmpId
        {
            get { return _empid; }
            set { _empid = value; }
        }
        /// <summary>
        /// Property EmpName
        /// </summary>
        public string EmpName
        {
            get { return _empName; }
            set { _empName = value; }
        }
        /// <summary>
        /// Property Company
        /// </summary>
        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }
        /// <summary>
        /// Property Department
        /// </summary>
        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }

        /// <summary>
        /// EmpType
        /// </summary>
        public string EmpType
        {
            get { return _empType; }
            set { _empType = value; }
        }
    }
}
