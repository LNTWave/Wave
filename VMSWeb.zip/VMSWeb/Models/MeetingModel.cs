﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VMSWeb.Models
{
    public class MeetingModel
    {
        private string _meetingID;
        private string _meetingName;
        private string _invitationCode;
        private string _hostID;
        private DateTime _meetingDate;
        private string _location;

        /// <summary>
        /// Property MeetingID
        /// </summary>
        public string MeetingID
        {
            get { return _meetingID; }
            set { _meetingID = value; }
        }

        /// <summary>
        /// Property MeetingName
        /// </summary>
        public string MeetingName
        {
            get { return _meetingName; }
            set { _meetingName = value; }
        }

        /// <summary>
        /// Property InvitationCode
        /// </summary>
        public string InvitationCode
        {
            get { return _invitationCode; }
            set { _invitationCode = value; }
        }

        /// <summary>
        /// Property HostID
        /// </summary>
        public string HostID
        {
            get { return _hostID; }
            set { _hostID = value; }
        }

        /// <summary>
        /// Property Meeting Date
        /// </summary>
        public DateTime MeetingDate
        {
            get { return _meetingDate; }
            set { _meetingDate = value; }
        }

        /// <summary>
        /// Property Location
        /// </summary>
        public string Location
        {
            get { return _location; }
            set { _location = value; }
        }
    }
}
