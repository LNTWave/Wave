﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VMSWeb.Models
{
    public class MeetingConfirmationModel
    {
        public VisitorModel VisitorDetails;
        public MeetingModel MeetingDetails;

         public string SucessMessage;
    }
}
