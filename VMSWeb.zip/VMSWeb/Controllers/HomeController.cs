﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Configuration;
using VMSWeb.Models;
using VMCWeb.ViewModel;
using VMCWeb.Controllers;
using VMS;
using ZXing;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;


namespace VMSWeb.Controllers
{
    public class HomeController : Controller
    {
        VMSDAL.VMSDAL objDAL = new VMSDAL.VMSDAL();
        VisitorViewModel vvm = new VisitorViewModel();

        //public static string path="C:\\Temp";
        public ActionResult Index()
        {

            QRCodeController qrcode = new QRCodeController();

            List<VisitorModel> visitorlist = new List<VisitorModel>();
            visitorlist = qrcode.GetVisitorList();// qrcode.dal.GetAllVisitor();
            vvm.strInvite = "Improper Picture. Please hold the phone correctly.";
            vvm.visitorList = visitorlist;
            //var request = new RestRequest("api/serverdata", Method.GET) {RequestFormat = DataFormat.Json}; 

            ViewBag.Title = "Home Page";
            return View(vvm);
        }



        [HttpPost]
        public ActionResult GetVisitorByInviteID(string invite)
        {
            //QRCodeController qrinvitecode = new QRCodeController();

            QRCodeController qrcode = new QRCodeController();

            List<VisitorModel> visitorlist = new List<VisitorModel>();
            visitorlist = qrcode.GetVisitorList();

            VisitorModel inv = visitorlist.Where(x => x.InvitationCode == invite).FirstOrDefault();
            //TODO Handle Null check With Appropriate Error Handling
            if (inv.StatusID==8)
            return View("_NotificationPopUp", inv);
            else 
            return View("_NotificationCheckoutPopUp", inv);

        }



        //QR Code starts
        /// <summary>
        /// Saves the image.
        /// </summary>
        /// <param name="imageData">The image data.</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveImage(string imageData)
        {
            string[] strOutput = new string[2];
            try
            {
                string fileNameWitPath = DateTime.Now.ToString().Replace("/", "-").Replace(" ", "- ").Replace(":", "") + ".bmp";
                using (FileStream fs = new FileStream(fileNameWitPath, FileMode.Create))
                {
                    using (BinaryWriter bw = new BinaryWriter(fs))
                    {
                        byte[] data = Convert.FromBase64String(imageData);
                        bw.Write(data);
                        bw.Close();
                    }
                }

                strOutput[0] = DecodeBarcode(fileNameWitPath);

            }
            catch { };
            return Json(strOutput, JsonRequestBehavior.AllowGet); ;
        }

        /// <summary>
        /// Decodes the barcode.
        /// </summary>
        /// <param name="imgpath">The imgpath.</param>
        /// <returns></returns>
        protected string DecodeBarcode(string imgpath)
        {
            var reader = new BarcodeReader();
            Bitmap currentBitmapForDecoding = new Bitmap(imgpath);
            string path = Path.GetFullPath(imgpath);
            string strResult = string.Empty;

            try
            {
                if (currentBitmapForDecoding != null)
                {
                    var result = reader.Decode(currentBitmapForDecoding);
                    if (result != null)
                    {
                        strResult = result.Text.ToString();
                        vvm.strInvite = strResult.Substring(0, 19);
                        //if (!(IsInviteCodeFormatMatching(strInvite)))
                        //{
                        //    strInvite = "Invalid QR code!!";
                        //}
                        //else
                            if (!IsQRCodeExists(strResult))
                                vvm.strInvite = "Invitation code not existing OR Invalid QR Code";
                    }
                }
            }
            finally
            {
                currentBitmapForDecoding.Dispose();
                currentBitmapForDecoding = null;
                //string fullPath = Server.MapPath(imgpath);
                if (System.IO.File.Exists(imgpath))
                    System.IO.File.Delete(imgpath);
            }

            return vvm.strInvite;
        }

        /// <summary>
        /// Determines whether [is invite code format matching] [the specified input].
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        protected bool IsInviteCodeFormatMatching(string input)
        {
            if (!Regex.IsMatch(input, "[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}"))
            {
                return false;
            }
            else
                return true;
        }

        private bool IsQRCodeExists(string Qrcode)
        {
            string strInvitationCode = Qrcode.Substring(0, 16);
            string strMeetingDate = Qrcode.Substring((Qrcode.Length - 8), 8);
            //string strEmailID = Qrcode.Substring(17,(17-())

            if (objDAL.CheckVisitorQrCode(strInvitationCode, strMeetingDate))
                return true;
            else
                return false;
        }
    }
}
