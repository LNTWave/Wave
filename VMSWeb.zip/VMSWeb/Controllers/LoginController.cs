﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Web.Security;
using VMCWeb.ViewModel;

namespace VMCWeb.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel lvm, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                string struName = Convert.ToString(lvm.UserLogin.UserName).ToUpper().Trim();
                string strPassword = Convert.ToString(lvm.UserLogin.PassWord).ToUpper().Trim();
                if (struName == "admin".ToUpper() && strPassword == "admin@123".ToUpper())
                {
                    FormsAuthentication.SetAuthCookie(lvm.UserLogin.UserName.ToUpper(), false);
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        //HostingEnvironment.QueueBackgroundWorkItem(ct => SendMailAsync(user.Email));
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("authenticationError", "User name or Password is wrong. Try it again");
                    //lblError.Text = "User name or Password is wrong. Try it again";
                }
            }
            return View(lvm);
        }
	}
}