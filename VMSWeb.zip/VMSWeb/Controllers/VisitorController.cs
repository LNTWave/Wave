﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Configuration;
using VMCWeb.ViewModel;
using System.Threading.Tasks;
using System.Web.Http;
//using System.Web.Http.ModelBinding;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using VMSWeb.Models;
using VMSWeb.Providers;
using VMSWeb.Results;
using VMApp.Models;
using VMSDAL;

namespace VMCWeb.Controllers
{
    public class VisitorController : Controller
    {
        // GET: Visitor
        public ActionResult Index()
        {
            return View();
        }

        //[System.Web.Routing.Route("IsregisteredUser")]
        //public VisitorModel IsregisteredUser()
        //{

        //    var result = 

        //    return new VisitorModel
        //    {
        //        EmpId = result.EmpId,
        //        Company = result.Company,
        //        Department = result.Department,
        //    };
        //}

        
    }
}