﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;
using ZXing;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;

namespace VMCWeb.Controllers
{
    public class QRController : Controller
    {
       public static string path = @"C:\Temp\";


       /// <summary>
       /// Saves the image.
       /// </summary>
       /// <param name="imageData">The image data.</param>
       /// <returns></returns>
        [HttpPost]
        public JsonResult SaveImage(string imageData)
        {
            string[] strOutput = new string[2];
            try
            {
                string fileNameWitPath = path + DateTime.Now.ToString().Replace("/", "-").Replace(" ", "- ").Replace(":", "") + ".bmp";
                using (FileStream fs = new FileStream(fileNameWitPath, FileMode.Create))
                {
                    using (BinaryWriter bw = new BinaryWriter(fs))
                    {
                        byte[] data = Convert.FromBase64String(imageData);
                        bw.Write(data);
                        bw.Close();
                    }
                }

                strOutput[0] = DecodeBarcode(fileNameWitPath);

            }
            catch { };
            return Json(strOutput, JsonRequestBehavior.AllowGet); ;
        }

        /// <summary>
        /// Decodes the barcode.
        /// </summary>
        /// <param name="imgpath">The imgpath.</param>
        /// <returns></returns>
        protected string DecodeBarcode(string imgpath)
        {
            var reader = new BarcodeReader();
            Bitmap currentBitmapForDecoding = new Bitmap(imgpath);
            string strResult = string.Empty;
            string strInvite = "Improper Picture. Please hold the phone correctly.";
            try
            {
                if (currentBitmapForDecoding != null)
                {
                    var result = reader.Decode(currentBitmapForDecoding);
                    if (result != null)
                    {
                        strResult = result.Text.ToString();
                        strInvite = strResult.Substring(0, 19);
                        if (!(IsInviteCodeFormatMatching(strInvite)))
                        {
                            strInvite = "Invalid QR code!!";
                        }
                    }
                }
            }
            finally
            {
                currentBitmapForDecoding.Dispose();
                currentBitmapForDecoding = null;
                //string fullPath = Server.MapPath(imgpath);
                if (System.IO.File.Exists(imgpath))
                    System.IO.File.Delete(imgpath);
            }

            return strInvite;
        }

        /// <summary>
        /// Determines whether [is invite code format matching] [the specified input].
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        protected bool IsInviteCodeFormatMatching(string input)
        {
            if (!Regex.IsMatch(input, "[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}"))
            {
                return false;
            }
            else
                return true;
        }
    }
}