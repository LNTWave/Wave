﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Web.Http;
//using System.Web.Mvc;

//using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using VMSWeb.Models;
using VMSWeb.Providers;
using VMSWeb.Results;
using VMApp.Models;
using VMSDAL;
using System.Configuration;
using VMS;
using System.Web.Script.Serialization;
//using Newtonsoft.Json;
using System;
using System.IO;
using VMS;
using System.Collections.Generic;
using VMCWeb.ViewModel;
//using System.Web.Http.ModelBinding;

namespace VMCWeb.Controllers
{
    [RoutePrefix("VMS")]
    public class QRCodeController : ApiController
    {
        public string connString;
        VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();



        //[Route("GetAllUsers")]
        //public UserModel GetAllUsers()
        //{

        //    var result = dal.GetAllUser()[0];

        //    return new UserModel
        //    {
        //        EmpId = result.EmpId,
        //        Company = result.Company,
        //        Department = result.Department,
        //    };
        //}

        [Route("GetVisitorList")]
        public List<VisitorModel> GetVisitorList()
        {
            connString = ConfigurationManager.ConnectionStrings["VMSConnection"].ConnectionString;
            List<VisitorModel> visitorlist = new List<VisitorModel>();
            List<Visitor> result = dal.GetAllVisitor();

            foreach (var item in result)
            {
                // string base64String = Convert.ToBase64String(item.ScanPhoto, 0, item.ScanPhoto.Length);

                VisitorModel vis = new VisitorModel
               {
                   VisitorID = item.VisitorID,
                   Name = item.Name,
                   Company = item.Company,
                   Designation = item.Designation,
                   ScanPhoto = item.ScanPhoto,
                   MeetingID = item.MeetingID,
                   InvitationCode = item.InvitationCode,
                   TimeIN = item.TimeIN,
                   TimeOUT = item.TimeOUT,
                   //QRCodeID = item.QRCodeID,
                   Comments = item.Comments,
                   BadgeNo = item.BadgeNo,
                   VisitorMailID = item.VisitorMailID,
                   StatusID = item.StatusID,
                   Nationality = item.Nationality,
                   Address = item.Address,
                   Token = item.Token,
                   ScanDocument = item.ScanDocument,
                   PhoneNo = item.PhoneNo,
                   HostID=item.HostID,
                   HostName=item.HostName,
                   CDesignation=item.CDesignation,
                   DeviceID=item.DeviceID,
                   HPhoneNo=item.HPhoneNo,
                   


               };
                visitorlist.Add(vis);

            }
            return visitorlist;
        }


        [HttpGet]
        [Route("ValidateInviteCode/{InviteCode}")]
        public InviteCodeModel ValidateInviteCode(string InviteCode)
        {
            VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
            var result = dal.ValidateInviteCode(InviteCode);

            return new InviteCodeModel
            {
                Success = result.Success,
                Message = result.Message,
                Token = result.Token,
                MeetingDate = result.MeetingDate,
                MeetingTime = result.MeetingTime,
                HostName = result.HostName,
                HostEmailID = result.HostEmailID,
                Location = result.Location,
                QRCode = result.QRCode,
                MeetingID = result.MeetingID,
                ISUserRegistered = result.ISUserRegistered,
                InviteeCode = result.InviteeCode,
                HostLocation = result.HostLocation,
                HostCompanyName = result.HostCompanyName,
                VisitorEmailID = result.VisitorEmailID,
                VisitorName = result.VisitorName,
                CheckedInStatus = result.CheckedInStatus,
                TimeIn = result.TimeIn,
                TimeOut = result.TimeOut
            };
        }

        /// <summary>
        /// Checks if the user has registered or not
        /// </summary>
        /// <param name="InviteCode"></param>
        /// <param name="Token"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("IsRegisteredUser/{InviteCode}/{Token}")]
        public VisitorModel IsRegisteredUser(string InviteCode, string Token)
        {
            VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
            var result = dal.IsregisteredUser(InviteCode, Token);

            return new VisitorModel
            {
                VisitorID = result.VisitorID,
                Name = result.Name,
                Company = result.Company,
                Designation = result.Designation,
                ScanPhoto = result.ScanPhoto,
                MeetingID = result.MeetingID,
                InvitationCode = result.InvitationCode,
                TimeIN = result.TimeIN,
                TimeOUT = result.TimeOUT,
                //QRCodeID = result.QRCodeID,
                //Comments = result.Comments,
                BadgeNo = result.BadgeNo,
                VisitorMailID = result.VisitorMailID,
                StatusID = result.StatusID,
                Nationality = result.Nationality,
                Address = result.Address,
                Token = result.Token,
                ScanDocument = result.ScanDocument,
                PhoneNo = result.PhoneNo,
                DeviceID = result.DeviceID
            };
        }

        /// <summary>
        /// Confirmation from the visitor for the meeting
        /// </summary>
        /// <param name="InviteCode"></param>
        /// <param name="Token"></param>
        /// <param name="QRCode"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("ConfirmMeeting/{InviteCode}/{Token}/{QRCode}")]
        public MeetingConfirmationModel ConfirmMeeting(string InviteCode, string Token, string QRCode)
        {
            VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
            var result = dal.ConfirmMeeting(InviteCode, Token, QRCode);

            MeetingConfirmationModel MeetingConfrm = new MeetingConfirmationModel();


            // MeetingDetails = new MeetingModel
            if (result.VisitorDetails != null)
            {
                MeetingConfrm.VisitorDetails = new VisitorModel();
                MeetingConfrm.VisitorDetails.VisitorID = result.VisitorDetails.VisitorID;
                MeetingConfrm.VisitorDetails.Name = result.VisitorDetails.Name;
                MeetingConfrm.VisitorDetails.Company = result.VisitorDetails.Company;
                MeetingConfrm.VisitorDetails.Designation = result.VisitorDetails.Designation;
                //MeetingConfrm.VisitorDetails.//ScanPhoto 
                MeetingConfrm.VisitorDetails.MeetingID = result.VisitorDetails.MeetingID;
                MeetingConfrm.VisitorDetails.InvitationCode = result.VisitorDetails.InvitationCode;
                MeetingConfrm.VisitorDetails.TimeIN = result.VisitorDetails.TimeIN;
                MeetingConfrm.VisitorDetails.TimeOUT = result.VisitorDetails.TimeOUT;
                //MeetingConfrm.VisitorDetails.QRCodeID = result.VisitorDetails.QRCodeID;
                MeetingConfrm.VisitorDetails.Comments = result.VisitorDetails.Comments;
                MeetingConfrm.VisitorDetails.BadgeNo = result.VisitorDetails.BadgeNo;
                MeetingConfrm.VisitorDetails.VisitorMailID = result.VisitorDetails.VisitorMailID;
                MeetingConfrm.VisitorDetails.StatusID = result.VisitorDetails.StatusID;
                MeetingConfrm.VisitorDetails.Nationality = result.VisitorDetails.Nationality;
                MeetingConfrm.VisitorDetails.Address = result.VisitorDetails.Address;
                MeetingConfrm.VisitorDetails.Token = result.VisitorDetails.Token;
                //MeetingConfrm.VisitorDetails.//ScanDocumeresult
                MeetingConfrm.VisitorDetails.PhoneNo = result.VisitorDetails.PhoneNo;
            }
            if (result.MeetingDetails != null)
            {
                MeetingConfrm.MeetingDetails.MeetingID = result.MeetingDetails.MeetingID;
                MeetingConfrm.MeetingDetails.MeetingName = result.MeetingDetails.MeetingName;
                MeetingConfrm.MeetingDetails.InvitationCode = result.MeetingDetails.InvitationCode;
                MeetingConfrm.MeetingDetails.Location = result.MeetingDetails.Location;
                MeetingConfrm.MeetingDetails.HostID = result.MeetingDetails.HostID;
                MeetingConfrm.MeetingDetails.MeetingDate = result.MeetingDetails.MeetingDate;
            }
            if (result.VisitorDetails == null || result.MeetingDetails == null || result.SucessMessage == null)
                MeetingConfrm.SucessMessage = "Cant Confirm the meeting because of Invalid InviteCode/Token/QRCode";
            else if (result.SucessMessage != null && result.SucessMessage == "Success")
                MeetingConfrm.SucessMessage = "Meeting Confirmed";
            return MeetingConfrm;
        }



        /// <summary>
        /// THis will be replaced with ui btn click 1st POE
        /// </summary>
        /// <param name="VisitorDetails"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RegisterVisitor")]
        public string RegisterVisitor([FromBody] Visitor VisitorDetails)
        {
            #region Non Neededd for test
            //MailCheck mailcheck = new MailCheck();
            //mailcheck.Main();
            //VisitorDetails = new Visitor();
            //VisitorDetails.Address = "wwww";
            //VisitorDetails.VisitorID = "q2";
            //VisitorDetails.Name = "Test User";
            //VisitorDetails.Company = "NoCompany";
            //VisitorDetails.Designation = "seller";
            //VisitorDetails.ScanPhoto = imageInsert(@"D:\user.png");
            //VisitorDetails.MeetingID = "45jk";
            //VisitorDetails.InvitationCode = "asf";
            //VisitorDetails.TimeIN = DateTime.Now;
            //VisitorDetails.TimeOUT = DateTime.Now;
            ////VisitorDetails.QRCodeID = "ad";
            //VisitorDetails.Comments = "ss";
            //VisitorDetails.BadgeNo = 1;
            //VisitorDetails.VisitorMailID = "as";
            //VisitorDetails.StatusID = 4;
            //VisitorDetails.Nationality = "Indian";
            //VisitorDetails.Address = "XYZ Cross";
            //VisitorDetails.Token = "NO";
            //VisitorDetails.ScanDocument = imageInsert(@"D:\user.png");
            //VisitorDetails.PhoneNo = "00000";
            //VisitorDetails.DeviceID = "TestId";
            //var JsonObj = ConvertToJson(VisitorDetails);
            //RegisterVisitor(JsonObj); 
            #endregion
            if (VisitorDetails != null)
            {
                VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
                return dal.RegisterUser(VisitorDetails);
            }
            return "Registration Failed";
        }

        public byte[] imageInsert(string path)
        {
            string filePath = Path.GetFullPath(path);
            string filename = Path.GetFileName(filePath);

            FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            br.Close();
            fs.Close();

            return bytes;
        }

        /// <summary>
        /// This will be shifted to ui and will be called in the above method 2 POE
        /// </summary>
        /// <param name="VisitorDetails"></param>
        /// <returns></returns>
        public object ConvertToJson(Visitor VisitorDetails)
        {
            return new JavaScriptSerializer().Serialize(VisitorDetails);
        }

        /// <summary>
        /// Register Visitor
        /// </summary>
        /// <param name="InviteCode"></param>
        /// <param name="Token"></param>
        /// <param name="QRCode"></param>
        /// <returns></returns>
        //[HttpPost]
        //[Route("RegisterVisitor/{JsonObject}")]
        //public string RegisterVisitor(object JsonObject)
        //{
        //    //Visitor VisitorDetails = new VMS.Visitor();
        //    //RegisterUser(VisitorDetails);
        //    //Visitor visitorDetails = new Visitor();
        //    //var obj = new StreamReader(JsonObject.ToString());
        //    //var serializer = new DataContractSerializer(typeof(Visitor));
        //    // var result = (Visitor)serializer.ReadObject(obj);

        //    Visitor visitorDetails = new Visitor();
        //    visitorDetails = new JavaScriptSerializer().Deserialize<Visitor>(JsonObject.ToString());

        //    VMSDAL.VMSDAL dal = new VMSDAL.VMSDAL();
        //    return dal.RegisterUser(visitorDetails);
        //}
    }
}
